package xyz.destiall.pixelate.graphics;

public interface Renderable {
    void render(Screen screen);
}
