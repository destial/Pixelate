package xyz.destiall.pixelate.events;

import xyz.destiall.java.events.Event;

public class EventPlace extends Event {
}
