package xyz.destiall.pixelate.items;

import xyz.destiall.pixelate.items.inventory.PlayerInventory;

public interface InventoryHolder {
    PlayerInventory getInventory();
}
