package xyz.destiall.pixelate.environment;

public enum Environment {
    OVERWORLD,
    CAVE,
    NETHER,
    END
}