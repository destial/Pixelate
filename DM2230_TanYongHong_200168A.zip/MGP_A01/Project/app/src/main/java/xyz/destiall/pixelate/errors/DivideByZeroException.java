package xyz.destiall.pixelate.errors;

public class DivideByZeroException extends Exception {}
