package xyz.destiall.pixelate.graphics;

public interface Updateable {
    void update();
}
