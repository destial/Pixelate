package xyz.destiall.pixelate.pathfinding.algorithms;

import java.util.LinkedList;

import xyz.destiall.pixelate.position.Location;

public class AStarAlgo extends Algorithm {

    public AStarAlgo() { }

    @Override
    public LinkedList<Location> findNewPath(Location start, Location end)
    {

        return path;
    }

}
