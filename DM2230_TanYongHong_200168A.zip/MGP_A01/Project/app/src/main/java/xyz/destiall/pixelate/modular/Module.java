package xyz.destiall.pixelate.modular;

import xyz.destiall.pixelate.graphics.Updateable;

public interface Module extends Updateable {
    void destroy();
}
