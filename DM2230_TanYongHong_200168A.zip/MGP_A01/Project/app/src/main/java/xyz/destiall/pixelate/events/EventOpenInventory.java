package xyz.destiall.pixelate.events;

import xyz.destiall.java.events.Event;

public class EventOpenInventory extends Event {
}
