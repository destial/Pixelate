package xyz.destiall.pixelate.environment.tiles;

public enum GenericModifierType {
    AXE_EFFICIENT,
    PICKAXE_EFFICIENT,
    SHOVEL_EFFICIENT,
    SHEAR_EFFICIENT,
    NONE,
}
